A ChangeLog file is for describing all the changes made to the source files.

Developers can keep their ChangeLog in ChangeLogs/github_username.txt

- <https://www.gnu.org/prep/standards/html_node/index.html>
- <https://www.gnu.org/prep/standards/html_node/Change-Logs.html#Change-Logs>
