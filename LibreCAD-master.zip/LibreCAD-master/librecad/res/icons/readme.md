The SVG icons in `librecad/res/icons` are mostly provided by [dellus][1]
and were all released under the CC0 license.  

- <https://github.com/LibreCAD/Resources>
- <https://creativecommons.org/publicdomain/zero/1.0/>

[1]:https://github.com/dellus
