<!-- 
This is a comment, not shown in your issue. You can delete it or leave it as it is.

Please give your issue an useful title.
And please enter as much information as possible into each paragraph below (###).
Think twice, post once ;-)

If your issue is about how to use LibreCAD consider to ask in the forum http://forum.librecad.org/.
The chances for fast help are much higher as there are much more user active, not only developer.
-->

### Expected behavior

### Observed behavior

### Steps to reproduce or sample file

### Operating System and LibreCAD version info

