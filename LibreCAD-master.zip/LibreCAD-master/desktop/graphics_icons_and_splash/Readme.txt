///////////////// LibreCAD logo /////////////////

Content:

Logo: Inkscape - Gimp
Splash Screen: Inkscape - Gimp
Icons 

//////////////////////////////////////////////////


Info:
Based on the point and the line as two basic elements of design, 
the point is squared due to the graphic representation in CAD (pixel), 
the design is simple showing the easy functions of the software.




---Spanish---

Informaci�n del logo:
basado en el punto y la l�nea como dos elementos b�sicos del dise�o,
el punto es cuadrado, debido a la representaci�n gr�fica en CAD (p�xel),
el dise�o es sencillo y representa las funciones del software.


Designed By:
Diego Alejandro Torres M. "Daltom Designer"
http://daltom.2082studio.com

Graphics work is supplied under the License : CC BY-SA